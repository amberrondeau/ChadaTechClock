/*
 * Clock.cpp
 *
 *  Created on: Apr 2, 2023
 *      Author: amberrondeau_snhu
 */

#include "Clock.h"

Clock::Clock() {
	// TODO Auto-generated constructor stub

}

Clock::~Clock() {
	// TODO Auto-generated destructor stub
}


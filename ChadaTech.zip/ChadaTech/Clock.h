/*
 * Clock.h
 *
 *  Created on: Apr 2, 2023
 *      Author: amberrondeau_snhu
 */

#ifndef CLOCK_H_
#define CLOCK_H_

class Clock {
public:
	Clock();
	virtual ~Clock();
};

#endif /* CLOCK_H_ */
